export default {
  columns: [
    {
      key: 'date',
      value: 'Date'
    },
    {
      key: 'action',
      value: 'Action'
    },
    {
      key: 'reason',
      value: 'Reason'
    }
  ],
  data: [
    {
      title: 'Integrated Eligibility',
      data: [
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 1'
        },
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Not enough cake'
        }
      ]
    },
    {
      title: 'Child Welfare',
      data: [
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 2'
        },
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 0'
        },
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 0'
        }
      ]
    },
    {
      title: 'Child Support',
      data: [
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 3'
        },
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 0'
        },
        {
          date: '12.15am 08 September 2017',
          action: 'Escalation requested',
          reason: 'Level 0'
        }
      ]
    }
  ]
};
