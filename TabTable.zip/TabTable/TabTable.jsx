import React from 'react';
import './TabTable.css';
import { constStyles } from './TabTableDefProps';
import PropTypes from 'prop-types';

class TabTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      stage: -1
    };
    this.handleChange = this.handleChange.bind(this);
  }

  componentWillMount() {
    this.updateStateInfo(this.props.data);
  }

  componentWillReceiveProps(nextProps) {
    this.updateStateInfo(nextProps.data);
  }

  updateStateInfo = (props) => {
    this.setState({
      data: props.data,
      columns: props.columns
    });
  };

  handleChange(index) {
    this.setState({ stage: index });
  }

  render() {
    return (
      this.state.data &&
      this.state.data.length > 0 && (
        <div className={constStyles.container}>
          <div className={constStyles.headerSection}>
            <Timeline {...this.state} handleChange={this.handleChange} />
          </div>
          <TableData stage={Number(this.state.stage)} data={this.state.data} columns={this.state.columns} />
        </div>
      )
    );
  }
}

const Timeline = (props) => {
  return (
    <div className={constStyles.timeline}>
      {props.data.map((data, index) => {
        return (
          <div key={index} className={constStyles.stageContainer} onClick={() => props.handleChange(index)}>
            <div>
              <h2>{data.title}</h2>
              <div className={`${props.stage === index ? constStyles.radioChecked : ''} ${constStyles.radioTabs}`}>
                <span>{data.data.length}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const TableData = (props) => {
  return (
    <div className={constStyles.tableContainer}>
      <div className={constStyles.table}>
        {props.data[props.stage] &&
        props.data[props.stage].data && (
          <table>
            <thead>
              <tr>{props.columns && props.columns.map((column) => <th key={column.key}>{column.value}</th>)}</tr>
            </thead>
            <tbody>
              {props.data[props.stage].data.map((data, index) => {
                return (
                  <tr key={index}>
                    {props.columns.map((column) => <td key={data[column.key]}>{data[column.key]}</td>)}
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

TabTable.propTypes = {
  data: PropTypes.shape({
    data: PropTypes.arrayOf(
      PropTypes.shape({
        title: PropTypes.float,
        text: PropTypes.string,
        data: PropTypes.arrayOf(
          PropTypes.shape({
            date: PropTypes.string,
            action: PropTypes.string,
            reason: PropTypes.string
          }).isRequired
        )
      }).isRequired
    ).isRequired
  })
};

export default TabTable;
